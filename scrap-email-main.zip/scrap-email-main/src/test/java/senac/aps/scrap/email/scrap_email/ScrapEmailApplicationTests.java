package senac.aps.scrap.email.scrap_email;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScrapEmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
